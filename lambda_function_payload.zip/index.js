exports.handler = function(event, context, callback) {
    console.log('Received event:', JSON.stringify(event, null, 4));
    var message = JSON.parse(JSON.stringify(event));
    console.log('Message received from SNS:');
    console.log("Event time: " , message.Records[0].eventTime);
    console.log("Event type: " , message.Records[0].eventName);
    console.log("S3 Bucket name: " , message.Records[0].s3.bucket.name);
    console.log("S3 Bucket ARN: " , message.Records[0].s3.bucket.arn);
    console.log("Filename: " , message.Records[0].s3.object.key);
    callback(null, "Success");
};
