var AWS = require('aws-sdk');
AWS.config.update({region: 'us-east-1'});
var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

exports.handler = function(event, context, callback) {
    console.log('Received event:', JSON.stringify(event, null, 4));
    var message = JSON.parse(JSON.stringify(event));

    var params = {
        TableName: 'insight-support-extensible-ingress',
        Item: {
            'id' : {N: '001'},
            'event' : {S: JSON.stringify(event)}
        }
    }

    ddb.putItem(params, function(err, data) {
        if (err) {
          console.log("Error", err);
        } else {
          console.log("Success", data);
        }
    });

    // console.log('Message received from SNS:');
    // console.log("Event time: " , message.Records[0].eventTime);
    // console.log("Event type: " , message.Records[0].eventName);
    // console.log("S3 Bucket name: " , message.Records[0].s3.bucket.name);
    // console.log("S3 Bucket ARN: " , message.Records[0].s3.bucket.arn);
    // console.log("Filename: " , message.Records[0].s3.object.key);
    // callback(null, "Success");
};
